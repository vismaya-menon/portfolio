


<?php
 
 $dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);


	$sql = "SELECT Phone,Address,Skype,Website FROM `about` WHERE Admin_ID = '1'";
	

	$result = $connection->query($sql);

	if ($result->num_rows > 0) {
    // output data of each row
		$row = $result->fetch_assoc();
        $phone=$row["Phone"]; 
		$address=$row["Address"]; 
		$skype=$row["Skype"]; 
		$website=$row["Website"]; 
	
		}
		
		
	$sql1 = "SELECT Email FROM `check_in` WHERE Admin_ID = '1'";
	

	$result1 = $connection->query($sql1);

	if ($result1->num_rows > 0) {
    // output data of each row
		$row1 = $result1->fetch_assoc();
        $email=$row1["Email"]; 
		
		}
		
		
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <link rel="stylesheet" type="text/css" href="./css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

  <link href="https://fonts.googleapis.com/css?family=Rajdhani|Roboto&display=swap" rel="stylesheet">
  <script>
function validateContact(){
    var uname = document.forms["contactus"]["uname"].value;
    var uemail = document.forms["contactus"]["uemail"].value;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var uphone = document.forms["contactus"]["uphone"].value;
    var phoneno = /^\d{10}$/;
    var comments = document.forms["contactus"]["comments"].value;
    
    if (uname == "") {
        alert("Please enter Name");
        return false;
    }
    if(!uemail.match(mailformat))
    {
        alert("Please enter a email address ex:example@email.com&body=comments");
        return false;
    }
    if(!uphone.match(phoneno))
    {
            alert("Please enter valid Phone ex: xxx xxx xxxx");
            return false;   
    }
    if (comments == "") {
        alert("Please enter comments");
        return false;
    }
    return true;
}

</script>
</head>
<body>
<div class="wrapper" id="wrapper">
  <div class="page1" >
      <span class ="page1">CONTACT ME</span>
  </div>
  <div class="contact">
    <div class="contact2">
      <h2>CONTACT ADDRESS</h2>
      
      <table>
        <tr>
                            <td class="icon" id="address"><i class="fa fa-map-marker"></i></td>
                            <td><strong>Address:</strong><?php echo "$address";?></td>
                        </tr>
                        <tr><td colspan='2'></td></tr>
                        
                        
                        <tr>
                            <td class="icon" id="phone"> <!-- id="phone" --><i class="fa fa-phone"></i></td>
                            <td><strong>Phone:</strong><?php echo "$phone";?></td>
                        </tr>
                        <tr><td colspan='2'></td></tr>
                        <tr>
                            <td class="icon" id="whatsapp"> <!-- id="whatsapp" --><i class="fa fa-whatsapp"></i></td>
                            <td><strong>Whatsapp:</strong><?php echo "$phone";?></td>
                        </tr>
                        <tr><td colspan='2'></td></tr>
              
                        
                        <tr>
                            <td class="icon" id="skype">  <!-- id="skype" --><i class="fa fa-skype"></i></td>
                            <td><strong>Skype:</strong><?php echo "$skype";?></td>
                        </tr>
                        <tr><td colspan='2'></td></tr>
                        <tr>
                            <td class="icon" id="email"> <!-- id="envelope" --><i class="fa fa-envelope"></i></td>
                            <td><strong>Email:</strong> <a href="#" class="link"><?php echo "$email";?> </a></td>
                        </tr>
                        <tr><td colspan='2'></td></tr>
                        <tr>
                            <td class="icon" id="website"> <!-- id="home1" --><i class="fa fa-home"></i></td>
                            <td><strong>Website:</strong> <a href="#" class="link"><?php echo "$website";?> </td>
                        </tr>                        
      </table>
      <div>
        <a href="#" class="fa fa-facebook" id="facebook"></a>
        <a href="#" class="fa fa-twitter" id="twitter"></a>
    	  <a href="#" class="fa fa-linkedin" id="linkedin"></a>
    	  <a href="#" class="fa fa-pinterest" id="pinterest"></a>
    	  <a href="#" class="fa fa-google-plus" id="google"></a>
    	  <a href="#" class="fa fa-snapchat" id="snapchat"></a>        
      </div>
      
    </div>
    <form id= "contactus" method="POST" name = "contactus" action="contactemail.php" >
    <div class="contact1" >

      <h2>LET'S HAVE A FUN</h2>
      <input placeholder="Your Name" type="text" required id="uname" name="uname"  required><br/>
    	<input placeholder="Email" type="email" id="uemail" name="uemail" required><br/>
    	<input placeholder="Phone" type="text" id="uphone" name="uphone" pattern="[0-9]{10}" required><br/>
    	<textarea placeholder="Your Message" rows="4" cols="50" id="comments" name="comments" required></textarea>
    	<br/>
    	<button class="button" type="submit" name="submit" onclick="contactemail.php">Send Now</button>
    </div><!--Javascript:validateContact();-->
  </form>
  </div>
  <footer id="footer">
    <div class="flex-container">            
      <a href="index.html" class=""><i class="fa fa-arrow-up"></i></a>
      </div>
    </footer>
  </div>
</body>
</html>


