<?php
if(isset($_POST["submit"])){

if($_POST["uname"]==""||$_POST["uemail"]==""||$_POST["uphone"]==""||$_POST["comments"]==""){
echo "Fill All Fields..";
}else{

$email=$_POST['uemail'];

$email =filter_var($email, FILTER_SANITIZE_EMAIL);

$email= filter_var($email, FILTER_VALIDATE_EMAIL);
if (!$email){
echo "Invalid Sender's Email";
}
else{
$email2 = $_POST['uemail'];
$subject = $_POST['uphone'];
$message = $_POST['comments'];
$headers = 'From:'. $email2 . "rn"; // Sender's Email
// Send Mail By PHP Mail Function
if(mail("vismayanaira@gmail.com", $subject, $message, $headers)){
echo "<script>window.alert('Your mail has been sent successfuly ! Thank you for your feedback');</script>";
echo "<script>window.location.href='contactmain.php'</script>";
}
else{
    echo "Not sent....";
}
}
}
}
?>