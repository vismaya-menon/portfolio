<?php
 
 $dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
?>
<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Skills</title>
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

    <link href="https://fonts.googleapis.com/css?family=Rajdhani|Roboto&display=swap" rel="stylesheet">
</head>
<body>
<div class="wrapper" id="wrapper">
    <div class="page1" >
        <span class ="page1">SKILLS</span>
    </div>
    <div id="SkillBox">
        <div class="row4" id="skillsfont">
            <div class="column4" >
                MARKETABLE SKILLS
                <?php
                           
                             $result2 = mysqli_query($connection,"SELECT * FROM marketable_skills where Admin_ID = '1');
                            
                            
                                while ($row2 = mysqli_fetch_assoc($result2)) 
                                {
                                    
                                    echo '
                                        <div class="SBar">
                                            <div id="SHTML" style="width:'.$row2["Percentage"].'%"> 
                                                <span class="SArea ">'.$row2["Technology"].'</span>
                                                <span class="Percent ">'.$row2["Percentage"].'</span>
                                            </div>
                                        </div>';
                                } 
                                
                                ?>
                
            
        </div>
        <div class="column4" >
                TRANSFERABLE SKILLS
                 <?php
                                        $result3 = mysqli_query($connection,"SELECT * FROM transferable_skills ");
                                            
                                        while ($row3 = mysqli_fetch_assoc($result3)) 
                                        {
                                            echo '
            <div class="SBar">
                <div id="SX" style="width:'.$row3["Percentange"].'%;">
                    <span class="SArea ">'.$row3["Title"].' </span>
                    <span class="Percent ">'.$row3["Percentage"].'%</span>
                </div>
            </div>';
              } 
                                ?>  
           
        </div>
    </div>


    <br><br><br><br> <br><br><br><br> <br><br><br><br>
    LANGUAGE SKILLS & KNOWLEDGE
    <?php
                        $result4 = mysqli_query($connection,"SELECT * FROM language_skills");
                            
                        while ($row4 = mysqli_fetch_assoc($result4)) 
                        {
                          
    <br><br><br>
      echo '<div class="item spanish">
        <h2>'.$row4["percentage"].'%</h2>
        <svg width="160" height="160" xmlns="http://www.w3.org/2000/svg">
            <g>
                <title>Layer 1</title>
                <circle class="circle_animation" r="69.85699" cy="81" cx="81" stroke-width="8" stroke="#6fdb6f" fill="none"/>
            </g>
        </svg>
        <h3>'.$row2["Technology"].'</h3>
    </div>';
    }
                        break;
                            
                    }
            ?>

   
        
    </div>
    <footer id="footer">
                <div class="flex-container">                        
                        <a href="index.html" class=""><i class="fa fa-arrow-up"></i></a>
                </div>
        </footer>
</div>

</body>
</html>
