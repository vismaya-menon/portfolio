<?php
 $dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';


	$mydb= mysqli_connect("$dbhost","$dbuser","$dbpass","$db");
	if ($mydb){
		echo"connected........";}
	else{
		echo "not connected....";}
		
	$sql = "INSERT INTO check_in (FirstName,LastName,Email,Username,Password)
    VALUES ('Karthik', 'T', 'kp@gmail.com','Kp','Kk@8143183704')";

    if ($mydb->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $mydb->error;
    }
    ?>