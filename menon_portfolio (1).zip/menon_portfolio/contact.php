<?php
 
 $dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
        if(isset($_POST["submit"]))
        { 
            if(!empty($_POST['uname']) && !empty($_POST['uemail']) && !empty($_POST['uphone']) && !empty($_POST['comments'])) 
             {
                  

                    $uname=$_POST['uname']; 
                    $uemail=$_POST['uemail']; 
                    $uphone=$_POST['uphone'];
                    $comments=$_POST['comments'];
                   
    
     // check if e-mail address is well-formed
    if ( preg_match("/^[a-zA-Z ]*$/",$uname) && filter_var($uemail, FILTER_VALIDATE_EMAIL) && preg_match("/^\d{10}$/", $uphone)) 
    {
     
    
    
                    
                    $sql2 = "INSERT INTO contactme (Name,Phone,Email,Message)
                    VALUES ('".$uname."','".$uphone."','".$uemail."','".$comments."')";
                    
                    if (($connection->query($sql2) === TRUE)) {
                        echo "New record created successfully";
                    } else {
                        echo "Error: " . $sql2 . "<br>" . $connection->error;
                    }
        
                    /* Redirect browser */  
                    header("Location: contact.html"); 
                   /* echo "It is matching "; */
    } 
    else{
        echo "please enter valid inforation";
    }
            }  
             else{
                 echo "All fields are required";
             }
        }
        CloseCon($connnection);
?>

