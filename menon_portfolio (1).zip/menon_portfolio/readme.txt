Student ID: 1001721679
CLOUD LINK : http://sreenidhitimmaiahgari.uta.cloud/Timmaiahgari_portfolio/home.html

Admin_Username: Sreenidhi
Admin_password: Nidhi17061995


Username : diaz
Password: Diaz1706
