<?php
 
  $dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$conn = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$conn->error);
    if (isset($_POST['signup'])) 
    {
        $fname = mysqli_real_escape_string($conn, $_POST['fname']);
        $lname = mysqli_real_escape_string($conn, $_POST['fname']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $user = mysqli_real_escape_string($conn, $_POST['user']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $cpassword = mysqli_real_escape_string($conn, $_POST['cpassword']); 
        if (!preg_match("/^[a-zA-Z ]+$/",$fname)) {
            $fname_error = " First Name must contain only alphabets and space";
        }
        if (!preg_match("/^[a-zA-Z ]+$/",$lname)) {
            $lname_error = "Last Name must contain only alphabets and space";
        }
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)) {
            $email_error = "Please Enter Valid Email ID";
        }
        if(strlen($password) < 6) {
            $password_error = "Password must be minimum of 6 characters";
        }       
        
        if($password != $cpassword) {
            $cpassword_error = "Password and Confirm Password doesn't match";
        }
        if (!$error) 
        {
             $fname = $_POST["fname"];
              $lname = $_POST["lname"];
              $email = $_POST["email"];

              $user = $_POST["user"];
              $password = $_POST["password"];

              $sql = "INSERT INTO check_in (FirstName,LastName,Email,Username,Password)
                VALUES ('$fname', '$lname', '$email','$user', '$password')";
                if($connection){
                  if(mysqli_query($connection,$sql))
                  {
                    echo "<script type='text/javascript'>window.alert('Signup sucessfull');
            window.location.href = 'home.html.#login';</script>";
                  }
                  else{
                    echo "<script type='text/javascript'>window.alert('Not sucessful');
            window.location.href = 'home.html.#checkin';</script>";
                    exit;

                  }
                }
    }
    else{
       echo("Failure");
        
    }      
    
?>

<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Homepage</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="./css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Rajdhani|Roboto&display=swap" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
</head>
<body>  
  <div class="home" id="home"> <!--wrapper div start -->
    <div class="nav1" id="nav1"> <!--nav div start -->
      <div class="head" id="head"> <!--head start -->
        
      <img src="./images/logo.png" class="logo" id="logo">
      <img src="./images/name.png" class="name" id="name">
      
      </div> <!--head end -->
      
      <ul>
        <li><a href="index.html">HOME</a></li>
        <li><a href="#login">LOGIN</a></li>
        <li><a href="#checkin">SIGN UP</a></li>

      </ul>
      <div class="footer1" id="footer1" style="position: relative;
  padding-top: 500px;
  font-size: 0.70em;
  padding-left: 4px;
  font-style: italic;
  text-align: center;
  color: white;
  padding-bottom: 10px;
  bottom: 0"> <!--copydiv start -->
        &copy; DiazApps ALL RIGHTS RESERVED BY <span style="color:#3046fc">Sreenidhi Timmaiahgari</span>
      </div> <!--copy div end -->

    </div> <!--nav div end -->

    <div class="main" id="main"><!--main div start s-->
      <p>HELLO I'M</p>
      <p class="name">SREENIDHI TIMMAIAHGARI</p>
      <div class="role" id="role"> <!--role div start -->
        <p>MOBILE DEVELOPER|</p>
        <div class="download"> <!-- download div start -->
        <button class="button">Download My CV <img src="./images/download3.png" class="downloadcv" id="downloadcv"> </button>
        </div> <!-- download div end -->
      </div><!--role div end -->
      
    </div> <!--main div end -->
  
  </div><!--wrapper div end -->
  <div id="login" class="overide">
      <form method="post" class="popup" action="#" name="loginform">
        Log-in<a class="close" href="index.html">&times;</a>
        <hr>
        User:<br>
        <input type="text" class="textbar" name="user1" id="user1" required>
        <br>
        Password:<br>
        <input type="password" class="textbar" name="password1" id="password1" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required>
        <hr>
        <button type="reset" id="button" class="button" onclick="location.href='index.html'">Cancel</button>
        <button type="submit" id="button" class="button" name = "loginButton" onclick='Javascript:Validateform();'>Get-in</button>
      </form>
  
  </div>  
  <div id="checkin" class="overide">
    <form method="post" class="popup" name="vform" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" >
        Check-in<a class="close" href="index.html">&times;</a>
        <hr>
        First Name:<br>
        <input type="text" class="textbar" name="fname" id="fname" pattern="[A-Za-z]{2,30}" required>
        <?php if (isset($fname_error)) echo $fname_error; ?>
        <br>
        Last name:<br>
        <input type="text" class="textbar" name="lname" id="lname" pattern="[A-Za-z]{2,30}" required>
        <?php if (isset($lname_error)) echo $lname_error; ?>
        <br>
        Email:<br>
        <input type="email" class="textbar" name="email" id="email" required>
        <?php if (isset($email_error)) echo $email_error; ?>
        <br>
        User:<br>
        <input type="text" class="textbar" name="user" id="user" required>
        <?php if (isset($cpassword_error)) echo $cpassword_error; ?>
        <br>
        Password:<br>
        <input type="password" class="textbar" name="password" id="password"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}"  required>
        <?php if (isset($password_error)) echo $password_error; ?>
        <br>
        Confirm password:<br>
        <input type="password" class="textbar" name="cpassword" id="cpassword"  pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" required>
        <hr>
        <button type="reset" id="button" class="button" onclick="location.href='index.html'">Cancel</button>
        <button type="submit" id="button" class="button" name="register" onclick='Javascript:Validate();'>Save</button>
    </form>
    <!-- <footer id="footer">
        <div class="flex-container">            
            <a href="index.html" class=""><i class="fa fa-arrow-up"></i></a>
        </div>
    </footer> -->
  </div>

</body>
</html>


<script>
  function checkPassword(str)
  {
    var re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
    return re.test(str);
  }


function Validate(){
    var fname = document.forms["vform"]["fname"].value;
    var lname = document.forms["vform"]["lname"].value;
    var email = document.forms["vform"]["email"].value;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var user = document.forms["vform"]["user"].value;

    var password = document.forms["vform"]["password"].value;
    var cpassword = document.forms["vform"]["cpassword"].value;
    
    if (fname == "") {
        alert("Please enter First Name");
        return false;
    }
    if (lname == "") {
        alert("Please enter Last Name");
        return false;
    }
    if(!email.match(mailformat))
    {
    /*if (email == "") {*/
        alert("Please enter a valid email address ex:example@email.com");
        return false;
    }
    if (user== "") 
    {
            alert("Please enter a user name");
            return false;
    }

     if(password != "" && password == cpassword) {
      if(!checkPassword(password)) {
        alert("Passwords must contain at least six characters, including uppercase, lowercase letters and numbers.");
       // vform.password.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      //vform.pssword.focus();
      return false;
    }
    /*if (password == "") {
        alert("Please enter password");
        return false;
    }
    if (cpassword == "") {
        alert("Please re-enter password");
        return false;
    }
    if (cpassword != password) {
        alert("Password doesnt match  ");
        return false;
    }*/
    return true;
}

function Validateform(){
  var user1 = document.forms["loginform"]["user1"].value;

  var password1 = document.forms["loginform"]["password1"].value;
  if (user1 == "") 
  {
    alert("Please enter a user name");
    return false;
  }
  if(password1 != "") {
      if(!checkPassword(password1)) {
        alert("Passwords must contain at least six characters, including uppercase, lowercase letters and numbers.");
       // vform.password.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered your password!");
      //vform.pssword.focus();
      return false;
    }

  /*if (password1 == "") 
  {
    alert("Please enter password");
    return false;
  }
  return true;*/
}
</script>
