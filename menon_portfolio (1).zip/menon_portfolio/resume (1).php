

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>experiences</title>
  <link rel="stylesheet" type="text/css" href="./css/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

  <link href="https://fonts.googleapis.com/css?family=Rajdhani|Roboto&display=swap" rel="stylesheet">
</head>
<body>
  <div class="wrapper" id="wrapper">
    <div class="page1" >
      <span class ="page1">RESUMES</span>
    </div> 
    <?php
        $dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);

                if ($connection){
                $sql = "SELECT * FROM resume";
                $res = $connection -> query($sql);
                if($res -> num_rows > 0){
                    $count = 1;
                    while($result = $res->fetch_assoc()){
                    if($count%2 != 0){
        ?>
    <div class="timeline" >
      <div class="container left" style= "--content: '<?php echo $result['Year']; ?>'">
        <div class="content1">
          <h2><?php echo $result['CompanyName']; ?></h2>
	      </div>
	      <div class="content2">
          <p><?php echo $result['Designation'] ." (".$result['Start_Date']." to " .$result['End_Date']. ") "; ?></p>
        </div>
      </div>
    <?php
      $count = $count + 1;
                    }
                    else{
    ?>
      <div class="container right" style= "--content: '<?php echo $result['Year']; ?>'">
        <div class="content1">
          <h2><?php echo $result['CompanyName']; ?></h2>
	      </div>
	      <div class="content2">
          <p> <?php echo $result['Designation'] ." (".$result['Start_Date']." to " .$result['End_Date']. ") ";?></p>
        </div>
      </div>
      
      
      
    </div>
    <?php
    $count = $count + 1;
                    }
 
 
    
    
                    }
                }
            }
    ?>
     <!-- </div> -->
    <footer id="footer">
      <div class="flex-container">            
        <a href="index.html" class=""><i class="fa fa-arrow-up"></i></a>
      </div>
    </footer>
  </div>
</body>
</html>
