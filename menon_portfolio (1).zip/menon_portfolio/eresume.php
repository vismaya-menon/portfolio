$dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
    
  if($connection){
   if(isset($_POST['resumeform'])){
           $Year = $_POST['year'];
           $Company = $_POST['company'];
           $Designation = $_POST['designation'];
           $start = $_POST['start'];
           $end = $_POST['end'];
           $query = "INSERT INTO resume (CompanyName,Designation,End_Date,Start_Date,Year) VALUES ('$Company ','$Designation','$end','$start')";
           echo $query;
           if(mysqli_query($connection, $query)){
               echo "<script type='text/javascript'>alert('Information Inserted!!');
                window.location.href='editresume.php';</script>";
            }
            else{
                echo "<script type='text/javascript'>alert('Information Not Inserted!!');
                window.location.href='editresume.php';</script>";
            }
        }