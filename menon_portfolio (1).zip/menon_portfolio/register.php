

<?php  
$dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
$fname = $lname = $email = $phone = $email = $user = $password= "";
/*$fnameErr = $lnameErr = $phoneErr = $emailErr = $userErr = $passwordErr = "";

function registerValidate()
{
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      if (empty($_POST["fname"])) {
        $fnameErr = "First Name is required";
      } else {
        $fname = test_input($_POST["fname"]);
      }
      if (empty($_POST["lname"])) {
        $lnameErr = "Last Name is required";
      } else {
        $lname = test_input($_POST["lname"]);
      }
    
      if (empty($_POST["email"])) {
        $emailErr = "Email is required";
      } else {
        $email = test_input($_POST["email"]);
      }
    
      if (empty($_POST["user"])) {
        $userErr = "User name is required";
      } else {
        $user = test_input($_POST["user"]);
      }
    
      if (empty($_POST["password"])) {
        $passwordErr = "password is required";
      } else {
        $password = test_input($_POST["password"]);
      }
    return true;
    }
    else{
        return false;
    }
}

if(registerValidate()){*/
    
  $fname = $_POST["fname"];
  $lname = $_POST["lname"];
  $email = $_POST["email"];

  $user = $_POST["user"];
  $password = $_POST["password"];

	$sql = "INSERT INTO check_in (FirstName,LastName,Email,Username,Password)
    VALUES ('$fname', '$lname', '$email','$user', '$password')";
    if($connection){
    	if(mysqli_query($connection,$sql))
    	{
    		echo "<script type='text/javascript'>window.alert('Signup sucessfull');
window.location.href = 'home.html.#login';</script>";
    	}
    	else{
    		echo "<script type='text/javascript'>window.alert('Not sucessful');
window.location.href = 'home.html.#checkin';</script>";
    		exit;

    	}
    }
    else{
       echo("Failure");
        
    }
    


   
?>