<?php
	$dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
		
	if($connection){
	    if(isset($_POST['updatepersonal'])){
	       $name = $_POST['fname'];
	$lastname = $_POST['lname'];
	
	$DateOfBirth  = $_POST['dobedit'];
	$Address = $_POST['address'];
	$Phone = $_POST['phoneedit'];
	$Nationality = $_POST['nationality'];
	$Skype = $_POST['skypeedit'];
	$Website = $_POST['website'];
	$Description = $_POST['description'];
	        	$sql = "UPDATE check_in SET FirstName='$name',LastName='$lastname' WHERE Admin_ID = 1";
	        $sql2 = "UPDATE about SET Phone='$Phone',Address='$Address',DOB='$DtaeOfBirth',Nationality='$Nationality',Description='$Description',Skype='$Skype',Website='$Website', WHERE Admin_ID = 1";
	        if(mysqli_query($connection, $sql2)){
	            echo "<script type='text/javascript'>alert('Information Updated!!');
                window.location.href='editpersonal.php';</script>";
	        }
	        else{
	            echo "<script type='text/javascript'>alert('Information Not Updated!!');
                window.location.href='editpersonal.php';</script>";
	        }
	    }
	}
?>