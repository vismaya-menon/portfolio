<?php
 
 $dbhost = 'localhost:3306';
 $dbuser = 'vismayam_root';
 $dbpass = 'vis@1816';
 $db = 'vismayam_wdm';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);


	$sql = "SELECT Phone,DOB,address,Nationality,Email FROM `aboutme`";
	

	$result = $connection->query($sql);

	if ($result->num_rows > 0) {
    // output data of each row
		$row = $result->fetch_assoc();
		$address=$row["address"]; 
		$dob=$row["DOB"]; 
		$nationality=$row["Nationality"]; 
	    $email=$row["Email"]; 
		}
		
		$sql1 = "SELECT Fname,LName FROM `aboutme`";
	

	$result1 = $connection->query($sql1);

	if ($result1->num_rows > 0) {
    // output data of each row
		$row1 = $result1->fetch_assoc();
		 $firstname=$row1["Fname"]; 
		$lastname=$row1["LName"];
        
		
		}
		
			$sql3 = "SELECT Summary FROM `aboutme`";
	

	$result3 = $connection->query($sql3);

	if ($result3->num_rows > 0) {
    // output data of each row
		$row3 = $result3->fetch_assoc();
		 $description=$row3["Summary"]; 
		
		
		}
		
		$result2 = $connection->query("SELECT ProfilePicture FROM about WHERE Admin_ID='1'");
    
    if($result2->num_rows > 0){
        /*$imgData = $result2->fetch_assoc();
        $img= $imgData["ProfilePicture"];
        */
        $img=mysqli_fetch_array($result2);
        
        
    }
		

?>

<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>about</title>
 <link rel="stylesheet" type="text/css" href="./css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

<link href="https://fonts.googleapis.com/css?family=Rajdhani|Roboto&display=swap" rel="stylesheet">
</head>
<body>
<div class="wrapper" id="wrapper">
<div class="page1" >
  <span class ="page1">ABOUT ME</span>
</div>


<div class="about">
  <div class="column left1">
      <img src="./images/profile.jpg" class ="propic">
    <!--<?php echo '<img src="data:image/jpeg;base64,'.base64_encode( $img['ProfilePicture'] ).'"  class ="propic"/>'; ?>" -->
    <p>Developer / 3D Design</p>
  </div>
  <div class ="column right1">
    <div class ="child">
      <div class="details">
        <i class="fa fa-user"></i>
        <span class="data">Name 
        <br><?php echo "$firstname $lastname";?></span>
      </div>
      <div class="details">
        <i class="fa fa-volume-control-phone"></i>
        <span class="data">Phone 
        <br><?php echo "*Hidden*";?></span>
      </div> 
      <div class="details">
        <i class=" fa fa-map-marker" id="marker"></i>
        <span class="data">Address 
        <br><?php echo "Arlington, Texas";?></span>
      </div>  
    </div>
    <div class ="child">      
      <div class="details1">
        <i class=" fa fa-envelope" id="envelope"></i>
        <span class="data">Email 
        <br><?php echo "$email";?></span>
      </div>
      <div class="details1">
        <i class=" fa fa-calendar"></i>
        <span class="data">Birthday 
        <br><?php echo "January 18";?></span>
      </div>
      <div class="details1">
        <i class=" fa fa-flag"></i>
        <span class="data">Nationality 
        <br><?php echo "$nationality";?></span>
      </div>
    </div>
    <div class= "coloumn2">
      <p> Social Profiles <!--<a href="#" class="fa fa-facebook" id="facebook"></a>
      <a href="#" class="fa fa-twitter" id="twitter"></a> -->
      <a href="https://www.linkedin.com/in/vismaya-menon-56ba01104/" class="fa fa-linkedin" id="linkedin"></a>
      <!--<a href="#" class="fa fa-pinterest" id="pinterest"></a>
      <a href="#" class="fa fa-google-plus" id="google"></a>
      <a href="#" class="fa fa-snapchat" id="snapchat"></a></p> 
      <br><p> <!--I have  than <strong> 10 years of experience </strong>in the field of <strong> Graphic Design, Web Design, Web Demorevelopement and Mobile Application.</strong> Specialized in Adobe Web & graphic designing tools and also others tools. Professional in Corporate branding, Graphic desigining, Web Designing, Visualization, 3D Design, graphics & animations for e-learning, illustrations, web icons, flash web banner, flash intro animations, logos, brochures, posters etc.</p>
      <p>Also in systems programming in web environment managing languages such as Html, Css, Javascript and Framework  like Bootstrip, Codeigniter and Laravel.</p>
      <p><strong>My objectives</strong>are increasing my knowledge in computer science fields and new technologies especially, Web developement and web Design field.</p>
      <p>Always lokking forward to learn new technologies and be a part of a huge change in the world.-->
      <br>
      <br>
      //<?php echo "$description";?> 
      <p> I am a Computer Science Graduate student at University of Texas at Arlington. I have around 2 years of work experience in Software development and Data Analysis. I worked as an iOS Developer in a start-up called InfiVention Technologied Pvt Ltd and made two chess apps. I enjoy coding and I am en excellent orator and organiser. </p>
      <br>
      <p>Yours sincerely,</p>
        <img src="./images/signature.PNG" class ="sign">
  </div>
</div>
<footer id="footer">
        <div class="flex-container">            
            <a href="index (1).html" class=""><i class="fa fa-arrow-up"></i></a>
        </div>
    </footer>
</div>
</body>
</html>
