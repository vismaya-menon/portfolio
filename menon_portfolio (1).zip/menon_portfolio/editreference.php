
<?php
 
 $dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);


	$sql = "SELECT Phone,DOB,Address,Nationality,Description,Website,Position,Skype FROM `about`";
	

	$result = $connection->query($sql);

	if ($result->num_rows > 0) {
    // output data of each row
		$row = $result->fetch_assoc();
        $phone=$row["Phone"]; 
		$address=$row["Address"]; 
		$dob=$row["DOB"]; 
		$nationality=$row["Nationality"]; 
		$description=$row["Description"];
		
		$website=$row["Website"];
		$position=$row["Position"];
		$skype=$row["Skype"];
	
		}
		
		$sql1 = "SELECT FirstName,LastName FROM `check_in`";
	

	$result1 = $connection->query($sql1);

	if ($result1->num_rows > 0) {
    // output data of each row
		$row1 = $result1->fetch_assoc();
		 $firstname=$row1["FirstName"]; 
		$lastname=$row1["LastName"];
      
		
		}

?>


<!DOCTYPE html>
<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
  <title>Homepage</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="./css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Rajdhani|Roboto&display=swap" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

  <style>
    input[type=text],input[type=date],input[type=textarea], select {
      width: 50%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    

    
    </style>
</head>
<body>  
  <div class="home" id="home"> <!--wrapper div start -->
    <div class="nav1" id="nav1"> <!--nav div start -->
      <div class="head" id="head"> <!--head start -->
        
      <img src="./images/logo.png" class="logo" id="logo">
      <img src="./images/name.png" class="name" id="name">
      
      </div> <!--head end -->
      
      <ul>
         <li><a href="index.html">USER HOME</a></li>
        <li><a href="admin.html">ADMIN HOME</a></li>
        <li><a href="editpersonal.php">ADMIN PANEL</a></li>
        <li><a href="home.html">LOGOUT</a></li>

      </ul>
     <div class="footer1" id="footer1" style="position: relative;
  padding-top: 500px;
  font-size: 0.70em;
  padding-left: 4px;
  font-style: italic;
  text-align: center;
  color: white;
  padding-bottom: 10px;
  bottom: 0"> <!--copydiv start -->
        &copy; DiazApps ALL RIGHTS RESERVED BY <span style="color:#3046fc">Sreenidhi Timmaiahgari</span>
      </div> <!--copy div end -->


    </div> <!--nav div end -->

    <div class="admin" id="admin"><!--main div start s-->
     <nav class="nav2" id="nav2">
                    <ul>
                        <li><a href="editpersonal.php">Personal</a></li>
                        <li><a href="editlogin.php">Login</a></li>
                        <li><a href="editreference.php">Reference</a></li>
                        <li><a href="edithire.php">HireMe</a></li>
                        <li><a href="editskills.php">Skills</a></li>
                        <li><a href="editresume.php">Resumes</a></li>
                        <!--<li><a href="editportfolio.php">Portfolio</a></li>-->
                        <li><a href="editsocial.php">Social</a></li>
                    </ul>
      </nav>
      <br>
      <br>
      <h2>Update Reference</h2>
      <br>
      <br>
      <form action="/action_page.php">
    <label for="refname">Name:</label><br>
    <input type="text" id="refname" name="refname" value="<?php echo htmlspecialchars($firstname); ?>" pattern="[A-Za-z]{2,30}" required><br>

    <label for="refdesc">Description:</label><br>
    <input type="textarea" id="refdesc" name="refdesc"  value="<?php echo htmlspecialchars($lastname); ?>" pattern="[A-Za-z]{2,30}"  required><br>

    <label for="refpic">Designation:</label><br>
    <input type="text" id="refpic" name="refpic"  value="<?php echo htmlspecialchars($phone); ?>"  required ><br>

    <label for="refpic">Picture:</label><br>
    <input type="file" id="refpic" name="refpic"  value="<?php echo htmlspecialchars($dob); ?>" required ><br>

<br>
    <button type="reset" id="button" class="button" onclick="location.href='admin.html'">Cancel</button>
        <button type="submit" id="button" class="button" name="register" onclick='Javascript:Validate();'>Save</button>
  <br><br>
     </form> 
    </div> <!--main div end -->
  
  </div><!--wrapper div end -->
  
  

</body>
</html>


<script>
  function checkPassword(str)
  {
    var re = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}$/;
    return re.test(str);
  }


function Validate(){
    var fname = document.forms["vform"]["fname"].value;
    var lname = document.forms["vform"]["lname"].value;
    var email = document.forms["vform"]["email"].value;
    var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    var user = document.forms["vform"]["user"].value;

    var password = document.forms["vform"]["password"].value;
    var cpassword = document.forms["vform"]["cpassword"].value;
    
    if (fname == "") {
        alert("Please enter First Name");
        return false;
    }
    if (lname == "") {
        alert("Please enter Last Name");
        return false;
    }
    if(!email.match(mailformat))
    {
    /*if (email == "") {*/
        alert("Please enter a valid email address ex:example@email.com");
        return false;
    }
    if (user== "") 
    {
            alert("Please enter a user name");
            return false;
    }

     if(password != "" && password == cpassword) {
      if(!checkPassword(password)) {
        alert("Passwords must contain at least six characters, including uppercase, lowercase letters and numbers.");
       // vform.password.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered and confirmed your password!");
      //vform.pssword.focus();
      return false;
    }
    /*if (password == "") {
        alert("Please enter password");
        return false;
    }
    if (cpassword == "") {
        alert("Please re-enter password");
        return false;
    }
    if (cpassword != password) {
        alert("Password doesnt match  ");
        return false;
    }*/
    return true;
}

function Validateform(){
  var user1 = document.forms["loginform"]["user1"].value;

  var password1 = document.forms["loginform"]["password1"].value;
  if (user1 == "") 
  {
    alert("Please enter a user name");
    return false;
  }
  if(password1 != "") {
      if(!checkPassword(password1)) {
        alert("Passwords must contain at least six characters, including uppercase, lowercase letters and numbers.");
       // vform.password.focus();
        return false;
      }
    } else {
      alert("Error: Please check that you've entered your password!");
      //vform.pssword.focus();
      return false;
    }

  /*if (password1 == "") 
  {
    alert("Please enter password");
    return false;
  }
  return true;*/
}
</script>
