<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Hireme</title>
 <link rel="stylesheet" type="text/css" href="./css/style.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>

<link href="https://fonts.googleapis.com/css?family=Rajdhani|Roboto&display=swap" rel="stylesheet">
</head>
<body>
    <div class="wrapper" id="wrapper">
        <div class="page1" >
          <span class ="page1">HIRE ME</span>
        </div>
        <?php
		$dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);

		if ($connection){
				
                $sql = "SELECT * FROM hire_me";
                $res = $connection -> query($sql);
                if($res -> num_rows > 0){
                    while($result1 = $res->fetch_assoc()){
	?>
        <div class="hire">
            <div class="hcol" >
                <img id="imghire" src="./images/car4.png"  alt="Car 1">
                <ul>
                    <li><?php echo $result1['Price']; ?></li>
                    <li><?php echo $result1['Title']; ?></li>
                    <li><?php echo nl2br($result1['Description']); ?></li>
                    <hr>
                    <li><button class="button"><a href="contactmain.php">Contact Us</a></button></li>
                </ul>
            </div>
            
            <?php
					}
                }
            }
		?>
            <!--<div class="hcol" >
                <img id="imghire" src="./images/car5.png" alt="Car 2" >
                <ul>
                    <li> &#36;650</li>
                    <li>Informative website design</li>
                    <li>Logo</li>
                    <li>Photo Editing</li>
                    <li>Site construction</li>
                    <li>Maintenance for 6 months</li>
                    <hr> 
                    <li><button class="button"><a href="contact.html">Contact Us</a></button></li>
                </ul>   
            </div>
            <div class="hcol">
                <img id="imghire" src="./images/car6.png" alt="Car 3" >
                <ul>
                    <li>&#36;1450</li>
                    <li>3D character design</li>   
                    <li>Character sketch</li>
                    <li>Digitization and evelopment</li>
                    <li>Animation</li>
                    <li>Video demo</li>
                    <hr>
                    <li><button class="button"><a href="contact.html">Contact Us</a></button></li>
                </ul>
            </div>-->
        </div>
        <footer id="footer">
        <div class="flex-container">            
            <a href="index.html" class=""><i class="fa fa-arrow-up"></i></a>
        </div>
    </footer>
    </div>

</body>
</html>
