

<?php  
$dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
if (isset($_POST['user1']) and isset($_POST['password1'])){
	
// Assigning POST values to variables.
$username = $_POST['user1'];
$password = $_POST['password1'];

// CHECK FOR THE RECORD FROM TABLE
$query = "SELECT * FROM `check_in` WHERE Username='$username' and Password='$password'";
 
$result = mysqli_query($connection, $query) or die(mysqli_error($connection));
$count = mysqli_num_rows($result); 

if ($count == 1){


echo "<script type='text/javascript'>window.alert('Login Credentials verified');
window.location.href = 'index.html';</script>";

}else{

echo "<script type='text/javascript'>alert('Invalid Login Credentials or user name not found');
window.location.href = 'home.html.#login';</script>";
//echo "Invalid Login Credentials";
}
}
?>