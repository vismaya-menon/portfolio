<html>
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>References</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="./css/style.css">
    <link href="https://fonts.googleapis.com/css?family=Rajdhani|Roboto&display=swap" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto' rel='stylesheet' type='text/css'>
</head>
<body>
    <div class="wrapper" id="wrapper">
        <div class="page1" >
            <span class ="page1">REFERENCES</span>
        </div>
        <?php
			$dbhost = 'localhost';
 $dbuser = 'sreenidh_admin';
 $dbpass = 'Sree17061995';
 $db = 'sreenidh_timmaiahgari_portfolio';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
                if ($connection){
                $sql = "SELECT * FROM reference";
                $res = $connection -> query($sql);
                if($res -> num_rows > 0){
                    $count = 1;
                    while($result = $res->fetch_assoc()){
                    
				?>
        <div id="refPage" >
            <div class="ref">
                <img src="images/referen/joe.jpg">
                <p id="refName">'<?php echo $result['Name']; ?>'</p>
                <p id="position">'<?php echo $result['Designation']; ?>'</p>
                <p id="referral">'<?php echo $result['Description']; ?>'</p>
            </div>
           <!-- <div class="ref">
                <img src="images/referen/rosy.jpg">
                <p id="refName">ROSY CORONADO</p>
                <p id="position">PSYCHOLOGIST</p>
                <p id="referral">"As always, great creative thinking for the best solution.<br>Luis Miguel is by far the most professional and knowledgeable provider I worked with. I will hire him again :)".</p>
            </div>
            <div class="ref">
                <img src="images/referen/yury.jpg">
                <p id="refName">YURY JAJITZKY</p>
                <p id="position">CEO / DEVELOPER</p>
                <p id="referral">"As always, great creative thinking for the best solution.<br>Luis Miguel is by far the most professional and knowledgeable provider I worked with. I will hire him again :)".</p>
            </div>
            <div class="ref">
                <img src="images/referen/kyss.jpg">
                <p id="refName">KYSS CHIRINOS</p>
                <p id="position">MarkeTING / DESIGNER</p>
                <p id="referral">"As always, great creative thinking for the best solution.<br>Luis Miguel is by far the most professional and knowledgeable provider I worked with. I will hire him again :)".</p>
            </div>
            <div class="ref">
                <img src="images/referen/carhil.jpg">
                <p id="refName">CARHIL MATOS</p>
                <p id="position">CEO / DEVELOPER</p>
                <p id="referral">"As always, great creative thinking for the best solution.<br>Luis Miguel is by far the most professional and knowledgeable provider I worked with. I will hire him again :)".</p>
            </div>
            <div class="ref">
                <img src="images/referen/leo.jpg">
                <p id="refName">MARK ZUCKERBERG</p>
                <p id="position">MARKETING / DESIGNER / MUSICIAN</p>
                <p id="referral">"As always, great creative thinking for the best solution.<br>Luis Miguel is by far the most professional and knowledgeable provider I worked with. I will hire him again :)".</p>
            </div>-->
           
        </div>
         <?php
                    }
                }
            }
		?>
            <footer id="footer">
            <div class="flex-container" style="position:relative;">                        
                <a href="index.html" class=""><i class="fa fa-arrow-up"></i></a>
            </div>
        </footer>       
    </div>
     
</body>
</html>
