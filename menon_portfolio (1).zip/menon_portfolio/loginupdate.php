
<?php
  $dbhost = 'localhost:3306';
 $dbuser = 'vismayam_root';
 $dbpass = 'vis@1816';
 $db = 'vismayam_wdm';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
if(isset($_POST["submit"]))
{  
  
    if(!empty($_POST['updateun']) && !empty($_POST['updatepwd'])) 
    {  
        $username=$_POST['updateun'];  
        $password=$_POST['updatepwd']; 
        $query ="update login set
                  user='$updateun', pwd='$updatepwd' where login_id='1'";
         $result = mysqli_query($connection, $query) or die(mysqli_error($connection));         
       echo "<script type='text/javascript'>window.alert('successful');
        window.location.href = 'editlogin.php';</script>";
    }
    else
    
    {

        echo "<script type='text/javascript'>alert('not successful');
        window.location.href = 'editlogin.php';</script>";
    //echo "Invalid Login Credentials";
    }
    
}

else
{
    echo "Invalid DB Connections";
}

?>
