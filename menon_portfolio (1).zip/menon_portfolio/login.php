<?php
 $dbhost = 'localhost:3306';
 $dbuser = 'vismayam_root';
 $dbpass = 'vis@1816';
 $db = 'vismayam_wdm';

$connection = mysqli_connect("$dbhost","$dbuser","$dbpass","$db") or die("Connect failure: %s\n".$connection->error);
if(isset($_POST["loginButton"]))
{  
  
    if(!empty($_POST['user1']) && !empty($_POST['password1'])) 
    {  
        $username=$_POST['user1'];  
        $password=$_POST['password1'];  
      
        // CHECK FOR THE RECORD FROM TABLE
        $query = "SELECT * FROM `login` WHERE user='$username' and pwd='$password'";
         
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));
        $count = mysqli_num_rows($result); 
    
        if ($count == 1 ){
    
        if($username=='Vismaya')
                        {
                            echo "<script type='text/javascript'>alert('welcome');
                                    window.location.href='admin.html';</script>";
                                    
                        }
                        else
                         {   
                        echo "<script type='text/javascript'>window.alert('Login Credentials verified');
                        window.location.href = 'index (1).html';</script>";
                        }

                }
             else{

        echo "<script type='text/javascript'>alert('Invalid Login Credentials or user name not found');
        window.location.href = 'home.html.#login';</script>";
    //echo "Invalid Login Credentials";
            }
    }
}

else
{
    echo "Invalid DB Connections";
}

?>